// main.cpp

// Demonstrates function calls between a C++ program
// and an external assembly language module.
// Copyright Kip R. Irvine, 2002. All rights reserved.
// Last update: 11/25/2002

#include <iostream>
#include <iomanip>
using namespace std;

extern "C" {
	// declare external ASM procedure:
	void DisplayTable();

	// declare local C++ functions:
	int askForInteger();
	void showInt( int value, int width );
	void newLine();
}

// program entry point
void main()
{
	DisplayTable();		// call ASM procedure
}

/* Functions called from ASM must be declared with 
the "C" modifier to prevent name decoration. The 
extern keyword exports the function name to the linker.
*/

// Prompt the user for an integer. 

int askForInteger()
{
	int n;
	cout << "Enter an integer between 1 and 90,000: ";
	cin >> n;
	return n;
}

// Display a signed integer with a specified
// width.

void showInt( int value, int width )
{
	cout << setw(width) << value;
}

// Display a newline.

void newLine()
{
	cout << endl;
}
