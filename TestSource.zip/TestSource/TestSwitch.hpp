import "TestSource\stdhpp\stdapi.hcc";

namespace UnitTesting //TestSwitch.hpp
{
	class TestSwitch
	{
		public const int open  = 1;
		public const int close = 2;
		public const int write = 3, 
						 read = 4;

		public static void RunTest(int option)
		{	
			switch(option)
			{
			case open:
				Console::WriteLn("Opening file...");
				break;
			case close:
				Console::WriteLn("Closing file...");
				break;
			case write:
				Console::WriteLn("Do Write to file...");
				break;
			case read:
				Console::WriteLn("Do Read from file...");
				break;
			case 5:
				Console::WriteLn("Do for 5 and follow to 6");
			case 6:
				{
				Console::WriteLn("Do 6, then finish");
				}
				break;
			default:
				Console::WriteLn("Invalid Option : ", option);
			};
		}
	};


	class Shape
	{		
		public virtual abstract double ComputeArea();		
	};

	class Circle: Shape
	{
		private double radius = 0.0;

	public double get:Radius()
	{
		return radius;
	}

	public void put:Radius(double value)
	{
		radius = value;
	}

	protected double Circumference()
	{
		return Math::pi() * Radius;
	}

		public virtual double ComputeArea()
		{
			return 2 * Circumference();
		}
	};

	class Square: Shape
	{
		private double dWidth = 0.0;
		private double dHeight = 0.0;

	public double get:Width()
	{
		return dWidth;
	}

	public void put:Width(double value)
	{
		dWidth = value;
	}

	public double get:Height()
	{
		return dHeight;
	}

	public void put:Height(double value)
	{
		dHeight = value;
	}

	public virtual double ComputeArea()
	{
		return Width * Height;
	}

	};

	class Triangle: Shape
	{
		private double dBase = 0.0;
		private double dHigh = 0.0;

	public double get:Base()
	{
		return dBase;
	}

	public void put:Base(double value)
	{
		dBase = value;
	}

	public double get:High()
	{
		return dHigh;
	}

	public void put:High(double value)
	{
		dHigh = value;
	}


	public virtual double ComputeArea()
	{
		return Base * High / 2;
	}
	};
}