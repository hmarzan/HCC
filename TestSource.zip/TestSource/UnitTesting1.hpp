import "TestSource\stdhpp\stdapi.hcc";
import "TestSource\stdhpp\TestVirtuals.hpp";
import "TestSource\stdhpp\TestFunctionParams.hpp";
import "TestSource\TestSwitch.hpp";


namespace UnitTesting
{
	class HelloWorld
	{
		public HelloWorld()
		{
			Console::WriteLn("The HelloWorld constructor");
		}

		public void SayHello(string text)
		{
			Console::WriteLn("this is what I have to say for the first time in H++ :", text);
		}

		public void ShowHello(string text)
		{
			System::ShowMessage(text, "H++ First program", System::IconInformation);
		}

		public void Destructor()
		{
			Console::WriteLn("The HelloWorld destructor");
		}
	};
//const definitions in H++

	const int ten = 10;
	
	const Int16 minusten = -ten;
	const int hundred = 100;	
	const Int32 max_length = 80;	
	const Int64 max_64 = 42545234; //just a test
	
	const Int64 max_64_neg = -max_64;
		
	namespace misc1
	{
		double array[10];

		const double pi = 3.1415927;	
		const float e = 2.2114;
		
		const int ten_plus = -UnitTesting::minusten;	
		const char ch1 = 'a', ch2 = 'z';	
		const string hello = "hello, world.";
		
		const string hell = "human", boy = "mistakes";
		
		const double dX = 4.99, dY = 9.4567;
			
		enum greek { alpha, beta, gamma };
		
		enum days_of_week { monday = 1, 
							tuesday,
							wednesday,
							thursday,
							friday,
							saturday,
							sunday,
						};
	
		//type definitions
		typename greek gletter;	
		typename days_of_week days_type;
	}
	

	class TestIntegers
	{
	private int nWidth	= 0;
	private int nHeight	= 0;

	//all properties 
	public int get:Width()
	{
		return nWidth;
	}

	public void put:Width(int value)
	{
		nWidth = value;
	}

	public int get:Height()
	{
		return nHeight;
	}

	public void put:Height(int value)
	{
		nHeight = value;
	}

	public int getArea()
	{
		return Width * Height;
	}

	public double getArea2()
	{
		return nWidth * nHeight * 1.0;
	}

	public static Int64 bigValue = 0x80000000h;

	public static void TestExpressions(void)
	{
		int hex_value = 0xDEADC0DEh;

		hex_value = hex_value << 0x10; //0xC0DE0000h

		hex_value = hex_value >> 8; //0x00C0DE00h

		hex_value = hex_value >> 8; //0x0000C0DEh

	//new type of expression down to zero from 4...
		int j = 0;

		volatile bool what = false;
				
		/*
		j = (4 + (--j))%4; //3
		j = (4 + (--j))%4; //1
		j = (4 + (--j))%4; //0
		j = (4 + (--j))%4; //3
		*/

		hex_value = 0;

		while(true)
		{
			j = (4 + (--j))%4; //321032103210
			
			if(++hex_value < 12)
				continue;

			what = (j%2)==0; //j==0

            break;
		}

		what = j==3; //false
		
		do{
			j = (4 + (--j))%4; //3210

			if(j==0)
				break;
			
		}while(j > 0);

		int x = 0;

		auto int y = 1, z = 2;

		volatile Int32 result = (y + 1) * z; //result==4		

		x++; //x==1
		++x; //x==2

		x += 14; //x==010h

		what = x==0x10h;

		x /= 4; //x==4

		--x;
		x--; //x==2

		x = 7 mod x; //

		what = x==1;

		x++; //x==2;

		x *= 10; //x==0x14h==20		

		x /= 5; //x==4

		x /=4; //x==1

		x %= 4; //x==1		

		y = 0x400h; //1024

		x = y div 15; // 68

		what = x == 68;

		z = 0x10; //16

		x = y * z; //16kb == 16 * 1024

		what = x==0x400;

		y = z = x; //all must have 16384 or 04000h

		x = y div 4; //x==4096

		what = x==4096;

		z = x%3; //x==1

		what = x==1;

		y = x div 3; //==1365

		what = x==1365;		

		result = ftoi(x / 3); //==1365

		result = x / (3 + 1); //==1024

		what = (result==1024);

		auto short a = 20000, b = 4, c = 10;

		result = a * b * c; //800,000

		what = result==0xC3500h;

		result /= 0x10; //==50000

		what = (result==50000);

		x = result%3; //==2

		result = Math::Round(a / 3) * 4; //round(6,666.666666....) * 5 aprox. == 33,335

		what = (result==33335);

		a = 1; b= 4; c=4;

		double disc = Math::Sqr(b)- 4*a*c;

		what = disc==0.0;

		double x1 = -b + Math::Sqrt(disc) / 2*a; 
		what = x1==-2.0;

		double x2 = -b - Math::Sqrt(disc) / 2*a;
		what = x2==-2.0;

		x = 1;
		Console::WriteLn("the value of x is: ", x);

		++x;
		Console::WriteLn("the value of x is: ", x); //2

		--x;
		Console::WriteLn("the value of x is: ", x); //1

		Console::WriteLn("the value of x is: ", x++); //1 -->2

		Console::WriteLn("the value of x is: ", x--); //2 -->1

		Console::WriteLn("the value is: ", x++ - 4 / (-1)); //5

		Console::WriteLn("the value is: ", --x - 4 / (-1)); //5

		Console::WriteLn("the value is: ", (x++ - 4) / (-1)); //3

		Console::WriteLn("the value is: ", (--x - 4) / (-1)); //3

		x = ten * 100; //==0x400

		what = x ==1000; //true

		what = ten*50 == 500; //true
/*
		hex_value = hex_value << 16; //0xC0DE0000h

		hex_value = hex_value >> 8; //0x00C0DE00h

		hex_value = hex_value >> 8; //0x0000C0DEh
*/

		UnitTesting::TestIntegers::bigValue *= 4;

		using namespace misc1;

		gletter alett = alpha;	
		
		days_type lundi = monday, 
				mardi = tuesday;
				  
		int length = 15, width = 10;
		double area = length * width;	
	
		double radius, circ;
			
		char letter = 'x';
		
		double darea = (length * width) * 0.9;

		a = 2;

		bool ternary = 4 >= a ? 999 < 1000 && 1 > 0 : 777==77.7*10 ; 7 == 111;

		ternary = (4 >= a) ? 999 > 1000 && 1 > 0 : 777 / 7 == 111;

		ternary = 4 < a ? 999 > 1000 && 1 > 0 : 777 / (3 + 4) == 111;


		return;
	}

	public int Calc1(int i, int ref j)
	{
		auto int nArea = j * Height;

		j = Width;	//reference keep this value

		j = i div 5;

		nArea = ftoi(j * Height * 1.0);
		//nArea = j * Height * 1.0;

		j *= 3; //new value for j

		return nArea;
	}

	public void Swap(int ref value1, int ref value2)
	{
		auto Int32 tmp = value1;
		value1 = value2;
		value2 = tmp;
	}

	public void Calc2(Int32 ref x, Int32 ref y)
	{
		int a = 1000;
		x = 9 * 3 * a; //27000
		y = a * 4 * 5; //20000
	}

	//members for specific integer expressions
	public void add(int v1, int v2, int ref res)
	{
		res = v1 + v2;

		Console::WriteLn("(+) the result is: ", res);
	}

	public void subs(int v1, int v2, int ref res)
	{
		res = v1 - v2;

		Console::WriteLn("(-) the result is: ", res);
	}

	public void multiply(int v1, int v2, int ref res)
	{
		res = v1 * v2;

		Console::WriteLn("(*) the result is: ", res);
	}

	public void divide(int v1, int v2, int ref res)
	{
		res = v1 div v2;

		Console::WriteLn("(div) the result is: ", res);
	}

	public void modulus(int v1, int v2, int ref res)
	{
		res = v1 % v2;

		Console::WriteLn("(mod) the result is: ", res);
	}

	public void divide2(int v1, int v2, int ref res)
	{
		res = Math::Round(v1 / v2);

		Console::WriteLn("(round(/)) the result is: ", res);
	}

	public void multiple_assignments(int ref param1, int param2)
	{
		int local = param2 = param1 = (0x400 * 1024) / 0x10;

		bool what = (local == 0x10000);
	}

	public int Factorial(int n)
	{
		System::Debug::BreakPoint();
	
		if(n==0)
			return 1;
		else
			return n * Factorial(n - 1);
	}

	public void SwapDebug(int ref value1, int ref value2)
	{
		System::Debug::OutputString("Swaping values...");
		Swap(value1, value2);
	}

	public double member1 = 0.0;
	public double member2 = 1.0;

	public double my_array1[2];
	public int my_array2[2];
	};


	class TestFloatingPoint
	{
		public TestFloatingPoint()
		{
			System::Debug::OutputString("constructing a TestFloatingPoint() object...");
		}

		public void Destructor()
		{
			System::Debug::OutputString("destroying a TestFloatingPoint() object...");
		}
		public double Power(double X, int n)
		{
			if(n==0)
				return 1;

			if(n%2==0)
				return Power(X * X, n/2);
			else
				return X * Power(X * X, n/2);
		}


		public static double speed(double distance, double time)
		{
			return distance / time;
		}

		public double Area(double minor_base, double major_base, double height)
		{
			double area = ((minor_base + major_base) * height) / 2.0;

			return area;
		}



	};

	class TestArrays
	{
		private string name;

		public string get:Name()
		{
			return name;
		}
		public void put:Name(string value)
		{
			name = value;
		}

		public static void printChars(char [] array, int n)
		{			
			for(int i=0;i<n;++i)
				Console::WriteLn("Char at i:[", i, "] == ", array[i]);

		}

		//implements the H++ statements before going into testing arrays...
		public static void DoTest(void)
		{
				TestIntegers array2[4];				

				array2[0].Width  = 100;
				array2[0].Height = 200;				

				Int64 nArea = array2[0].Width;

				nArea = array2[0].Width * array2[0].Height;

				array2[0].member1 = Math::pi();
				array2[0].member1 = Math::log_e_base2();
				

				array2[1].Width  = 100;
				array2[1].Height = 200;

				nArea = array2[1].Width * array2[1].Height;

				array2[2].Width  = 100;
				array2[2].Height = 200;

				nArea = array2[2].Width * array2[2].Height;


				array2[3].my_array1[0] = 9.99;
				array2[3].my_array2[0] = ftoi(9.99);

				string name = "Harold L. Marzan";
				printChars(name, StringHandling::StringLength(name));

				char my_name_is[20];

				my_name_is[0] = 'H';
				my_name_is[1] = 'a';
				my_name_is[2] = 'r';
				my_name_is[3] = 'o';
				my_name_is[4] = 'l';
				my_name_is[5] = 'd';
				my_name_is[6] = '\0';

				Console::WriteLn("My name is :", my_name_is);

				printChars(my_name_is, StringHandling::StringLength(my_name_is));

				char arr[10][20];				

				printChars(arr[9], StringHandling::StringLength(arr[9]));

				string arr_of_strings[4];

				arr_of_strings[0] = "Harold ";
				arr_of_strings[1] = "Lawrence ";
				arr_of_strings[2] = "Marzan ";
				arr_of_strings[3] = "Mercado.";
				
				for(unsigned int i=0;i<4;++i)
				{
					printChars(arr_of_strings[i], StringHandling::StringLength(arr_of_strings[i]));
				}

				StringHandling::StringCopy(my_name_is, name, StringHandling::StringLength(name));
				printChars(my_name_is, StringHandling::StringLength(my_name_is));
		}
	};

	namespace Test1
	{
		class TestRunner
		{
			public static void main(/*int argc, string[] argv*/)
			{
__HELLO_PART:
				HelloWorld hello();

				string say = "Hello World from H++!!!";

				hello.SayHello(say);

				hello.ShowHello(say);

				TestIntegers tester1;

				tester1.Width	=  0x400h * 1024; //1mb
				tester1.Height	= 0x20h; //

				int nWidth	= tester1.Width,
					nHeight = tester1.Height;

				auto Int64 nArea = tester1.Width * tester1.Height;

				with(tester1)
				{
					.Width	= 0x666h;
					.Height = 0x777h;
				}

				//int __CALC_FACTORIAL = 0;

				goto __CALC_FACTORIAL;

				debugger

				nArea = nWidth * nHeight;

				int n = 7;

				Integers_Inline::Test();
				
				for(int index=0; index<100; index++)
				{
					Console::WriteLn("Current Index :", index );
				}

				for(;;)
				{
					//infinite loop
					if(--index==0)
						break;
				}

				bool what = !(index==0);

__CALC_FACTORIAL:

				int nf = tester1.Factorial(n);

				--n;
				if(n==0)
					goto __END_FACTORIAL;

				goto __CALC_FACTORIAL;

__END_FACTORIAL:

				//only the reference param will be assigned whe the function return to main...
				int myRef1 = 0;
				int myVar1 = 0;

				debugger;

				tester1.multiple_assignments(myRef1, myVar1);

				Console::WriteLn("The value of myRef1 must be 65536 ==", myRef1);
				Console::WriteLn("The value of myVar1 is not 65536 but zero", myVar1);

				Console::WriteLn("(int)the area is: ", tester1.getArea());
				Console::WriteLn("(double)the area is: ", tester1.getArea2());

				auto Int32 result = 0;
				tester1.add(1024, 3072, result); //result==4096

				tester1.subs(1024, 3072, result); //result==-2048

				tester1.modulus(4096, 6, result); //result==4

				tester1.multiply(3, 927, result); //result==2781==0xADDh

				tester1.divide(4096, 6, result); //result==682

				tester1.divide2(4096, 6, result); //result==682.66666 aprox. 683				

				//test all kind of H++ integer expressions...
				TestIntegers::TestExpressions();
				
				int val1 = 1, val2 = 2;

				what = false;

				tester1.Swap(val1, val2);

				what = val1 == 2 && val2==1; //true

				tester1.Calc2(val1, val2);

				what = val1 == 27000 && val2==20000; //true

				tester1.Swap(val1, val2);

				tester1.SwapDebug(val1, val2);

				what = val1 == 20000 && val2==27000; //true

				tester1.Calc1(val1, val2);

				what = val2!=27000; //true

				val1 = val1 << 24;

				TestFloatingPoint fpTester();

				double _pow = fpTester.Power(2.0, 32);

				int array1[100];

				for(index = 0; index < sizeof(array1); )
				{
					array1[index] = ftoi((index + 1) * 9.45);
					index++;
				}

				TestArrays::DoTest();

				Rnd rnd(Math::Round(0x400 * Math::log_10_base2() + 1.0));

				goto _BlockRndDoubles;

				Console::WriteLn("Pseudo-Random Integer values:");
				Console::WriteLn("(1)A pseudo-random value: ", rnd.NextInt());
				Console::WriteLn("(2)A pseudo-random value: ", rnd.NextInt());
				Console::WriteLn("(3)A pseudo-random value: ", rnd.NextInt());
				Console::WriteLn("(4)A pseudo-random value: ", rnd.NextInt());
				Console::WriteLn("(5)A pseudo-random value: ", rnd.NextInt());
				Console::WriteLn("(6)A pseudo-random value: ", rnd.NextInt());

_BlockRndDoubles:

				Console::WriteLn("Pseudo-Random Double values:");
				Console::WriteLn("(1)A pseudo-random value: ", rnd.NextDbl());
				Console::WriteLn("(2)A pseudo-random value: ", rnd.NextDbl());
				Console::WriteLn("(3)A pseudo-random value: ", rnd.NextDbl());
				Console::WriteLn("(4)A pseudo-random value: ", rnd.NextDbl());
				Console::WriteLn("(5)A pseudo-random value: ", rnd.NextDbl());
				Console::WriteLn("(6)A pseudo-random value: ", rnd.NextDbl());
				//

				using namespace UnitTesting::TestVirtuals;

				double res = 0.0;

				SimpleRV srv();

				res = srv.Sample();
				Console::WriteLn("(1)A simple random variable has : ", res, " as its value.");
				res = srv.Sample();
				Console::WriteLn("(2)A simple random variable has : ", res, " as its value.");
				res = srv.Sample();
				Console::WriteLn("(3)A simple random variable has : ", res, " as its value.");
				res = srv.Sample();
				Console::WriteLn("(4)A simple random variable has : ", res, " as its value.");
				Console::WriteLn("my name is", srv.Name());

				res = 1.0;

				UniformRV urv(Math::log_e_base2(), Math::log_2_base_e());

				res = urv.Sample();
				Console::WriteLn("(1)An uniform random variable has : ", res, " as its value.");
				res = urv.Sample();
				Console::WriteLn("(2)An uniform random variable has : ", res, " as its value.");
				res = urv.Sample();
				Console::WriteLn("(3)An uniform random variable has : ", res, " as its value.");
				res = urv.Sample();
				Console::WriteLn("(4)An uniform random variable has : ", res, " as its value.");
				Console::WriteLn("my name is", urv.Name());

				res = 0.0;

				ExponentialRV erv(Math::pi());

				res = erv.Sample();
				Console::WriteLn("(1)An exponential random variable has : ", res, " as its value.");
				res = erv.Sample();
				Console::WriteLn("(2)An exponential random variable has : ", res, " as its value.");
				res = erv.Sample();
				Console::WriteLn("(3)An exponential random variable has : ", res, " as its value.");
				res = erv.Sample();
				Console::WriteLn("(4)An exponential random variable has : ", res, " as its value.");
				Console::WriteLn("my name is", erv.Name());

				
//				goto _Alpha;
				TestSwitch::RunTest(TestSwitch::open);
//				goto _Omega;
				

				double^ p = new double;

				
				*p = 3.141516927;

				res = *p;
				

				destroy p;

				/*
				p = &res;

				*p = 9.99;
				*/

				TestFloatingPoint^ fpTester_ptr = new TestFloatingPoint();

				_pow = fpTester_ptr.Power(2.0, 64);

				destroy fpTester_ptr;

								
				int [][] iptr = new int[10][10];	//10 * 10 * 4 = 400 bytes

				iptr[0][0] = 145;
				iptr[1][9] = 541;
				iptr[2][7] = 561;
				iptr[3][9] = 123;

				destroy iptr;

				iptr = null;

				int ^ xptr = null;

				xptr = new int;

				destroy xptr;
				
				int [] ii2ptr = null;

				TestIntegers xtarget,
							 ysource;

				ysource.Width = 0x666;
				ysource.Height = 0x777;

				//to test the object copy feature...
				xtarget = ysource;

				val1 = 5, val2 = 3;		

				xptr = xptr + 1;				

				/*TODO
				iptr = new int[val1 *3 ][(val2 * 4)];	//now [15][12] == 720 bytes
				destroy iptr;
				*/
				
				//testing sizeof operators

				int npi = sizeof(misc1::pi);

				npi = sizeof pi;

				int nint = sizeof(int),
					ndbl = sizeof(double),
					ni64 = sizeof Int64,
					ntit = sizeof(TestIntegers),
					nptr = sizeof(p),
					narr = sizeof(iptr),
					nar2 = sizeof(array1),
					nar3 = sizeof(misc1::array);

				nint = sizeof int + sizeof double;

				nint = sizeof(int) + sizeof(Int64);

				if(nint >= ndbl && ni64 < ntit)
				{
					Console::WriteLn("This is getting complex and better each time!");
				}				

				Circle obj;

				obj.Radius = 115.456;

				auto double area = obj.ComputeArea();

				Square sq;

				sq.Width = 500.456;
				sq.Height = 1045.4564;

				sq.ComputeArea();

				Triangle tri;

				tri.Base = 450.4564;
				tri.High = 4572.4564;

				tri.ComputeArea();
/*
_Alpha:
				//
				res = 0.0;
_Omega:
				//
				res = 1.0;			
*/				
			}
		};
	}
}